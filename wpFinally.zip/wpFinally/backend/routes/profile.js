const express = require("express");
const path = require("path");
const pool = require("../config");
const fs = require("fs");
const multer = require("multer");

router = express.Router();

// SET STORAGE
const storage = multer.diskStorage({
    destination: function (req, file, callback) {
      callback(null, "./static/uploads");
    },
    filename: function (req, file, callback) {
      callback(
        null,
        file.fieldname + "-" + Date.now() + path.extname(file.originalname)
      );
    },
  });
  const upload = multer({ storage: storage });


router.put("/profile/:user_id",upload.single("newImage"),async function (req, res, next) {
    console.log("Profile")
    const username = req.body.username
    const firstname = req.body.firstname
    const lastname = req.body.lastname
    const email = req.body.email
    const file = req.file;
    const conn = await pool.getConnection()
    await conn.beginTransaction();
    

    try {
       
        await conn.query(
        'UPDATE user SET username=?,firstname=?,lastname=?,email=? WHERE user_id=?',[username,firstname,lastname,email,req.params.user_id])
        if(req.body.image == undefined){
            await conn.query('UPDATE user SET image=? WHERE user_id=?',[file.path.substring(6),req.params.user_id])
          }
        console.log('success update profile')
        conn.commit()
        res.send("success!");
    } 
    catch (err) {
        await conn.rollback();
        next(err);
    } 
    finally {
        console.log('finally')
        conn.release();
    }
    return;

});


exports.router = router;
